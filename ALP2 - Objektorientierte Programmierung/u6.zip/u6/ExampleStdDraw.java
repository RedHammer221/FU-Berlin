package u6;

public class ExampleStdDraw {
	
	public static void main( String[] args) {
		StdDraw.setXscale(0, 200);
		StdDraw.setYscale(0, 200);
		StdDraw.rectangle(100, 100, 25, 25);
		StdDraw.setPenColor(StdDraw.GRAY);
		StdDraw.filledCircle(30, 30, 30);
		StdDraw.line(3, 190, 150, 3);
	}

} // end of class ExampleStdDraw
