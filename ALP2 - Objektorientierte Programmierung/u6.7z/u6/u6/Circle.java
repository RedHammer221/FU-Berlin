public class Circle {
    double x;
    double y;
    double radius;

    public Circle(double x, double y, double radius)
    {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    public Circle()
    {
        this (0,0,10);
    }

    public double getX() { return x; }
    public double getY() { return y; }
    public double getRadius() { return  radius; }



    public void draw()
    {
        StdDraw.circle(x, y, radius);
    }

    public Circle clone()
    {
        return new Circle(x,y,radius);
    }

    public double getSurface()
    {
        return Math.PI * Math.pow(radius, 2);
    }

    public int compareTo(Circle c)
    {
        double thisCircle = this.getSurface();
        double secondCircle = c.getSurface();

        if (thisCircle < secondCircle) { return  -1;}
        if (thisCircle == secondCircle) { return  0;}
        else { return  1;}
    }

    public boolean contains(Circle c)
    {
        double xSecond = c.getX();
        double ySecond = c.getY();
        double radiusSecond = c.getRadius();

        double xDiff = xSecond - x;
        double yDiff = ySecond - y;

        if (xDiff < 0) { xDiff = xDiff * (-1); }
        if (yDiff < 0) { yDiff = yDiff * (-1); }

        double underRoot = Math.pow(xDiff, 2) + Math.pow(yDiff, 2);
        double distance = Math.sqrt(underRoot) + radiusSecond;

        if (distance <= radius) { return true; }
        else { return false; }

    }

}