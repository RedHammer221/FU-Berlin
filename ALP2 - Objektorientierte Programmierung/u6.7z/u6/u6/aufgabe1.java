import java.util.Scanner;

// Aufgabe 1
public class Nr1{
    public static void main(String[] args) {
        int a;
        int b;
        int ergebnis = 0;
        Scanner eingabe = new Scanner(System.in);

        System.out.print("Bestimmen Sie den ersten Wert: ");
        a = eingabe.nextInt();
        System.out.print("Bestimmen Sie den zweiten Wert: ");
        b = eingabe.nextInt();
        eingabe.close();

        System.out.print(a+" * "+b+" = ");

        while(a > 0) {
            System.out.println(a+" "+b); //Anzeigen der Zwischenergebnisse
            if(a%2 == 1) { //Geht in die Schleife, wenn a == ungerade
                ergebnis = ergebnis + b;
            } //end if
            b = b + b;
            a = a >> 1;
        } //end while
        System.out.println("Das Ergebnis lautet: "+ergebnis);
    } //end main
} //end class