import java.util.Random;
public class driverUE06 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Circle circle = new Circle();
        ZInteger one = new ZInteger(0,3);
        ZInteger second = new ZInteger(0,4);
        TreeDoorsSimulator treeDorrs = new TreeDoorsSimulator();
        ExampleStdDraw test = new ExampleStdDraw();
        StarsAufgabe03 starsAufgabe03 = new StarsAufgabe03();
        PictureAufgabe3 pictureAufgabe3 = new PictureAufgabe3();
        ZInteger erg = one.multiply(second);

        System.out.println(erg.toInt());
        System.out.println(erg.toString());


        Random wuerfel = new Random();
        System.out.println(wuerfel.nextInt(3));

        treeDorrs.play(true);
        treeDorrs.testing(100);
        //test.main(args);
        pictureAufgabe3.draw();
