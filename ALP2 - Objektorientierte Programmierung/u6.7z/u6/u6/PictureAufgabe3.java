
public class PictureAufgabe3 {
    public void draw()
    {
        double[] x = new double[200];
        double[] yFirstCircel = new double[200];
        double[] ySecondCircel = new double[200];

        double[] yFirstLine = new double[200];

        int i = 0;

        StdDraw.setXscale(0, 200);
        StdDraw.setYscale(0, 200);

        while (i < 200)
        {
            x[i] = i;
            yFirstCircel[i] = 200 - Math.sqrt(Math.pow(200, 2) - Math.pow((x[i] - 200), 2));
            ySecondCircel[i] = Math.sqrt(Math.pow(200, 2) - Math.pow((x[i]), 2));

            yFirstLine[i] = 200 - Math.sqrt(Math.pow((x[i]), 2));
            //System.out.println(Math.sqrt(Math.pow((x[i]), 2)));
            i++;
        }

        i = 0;

        while (i < 200)
        {
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.line(0, i, x[199-i], yFirstCircel[199-i]);
            StdDraw.line(i, 0, x[i], yFirstCircel[i]);

            StdDraw.setPenColor(StdDraw.BLUE);
            StdDraw.line(i, 200, x[i], ySecondCircel[i]);
            StdDraw.line(200, i, x[199-i], ySecondCircel[199-i]);
            System.out.println(ySecondCircel[i]);

            //StdDraw.line(200, 200, x[i], yFirstLine[i]);


            i++;
        }

        // Keine Ahnung, wie man das Gitter berechnen soll?!
        StdDraw.setPenColor(StdDraw.GREEN);
        StdDraw.line(0, 0, 200, 200);

        StdDraw.setPenColor(StdDraw.PINK);
        StdDraw.line(0, 200, 200, 0);
        // END


        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.circle(200, 200, 200);
        //StdDraw.polygon(x, y);
        //StdDraw.line(0, 50, 50, 67);
        StdDraw.setPenColor(StdDraw.BLUE);
        StdDraw.circle(0, 0, 200);


    }

}