
public class StarsAufgabe03 {

    public void draw()
    {
        double[] x = new double[2];
        double[] y = new double[2];

        x[0] = 1;
        x[1] = 2;
        y[0] = 1;
        y[1] = 2;



        StdDraw.setXscale(0, 200);
        StdDraw.setYscale(0, 200);
        StdDraw.polygon(x, y);
    }

}