import java.util.Scanner;
import java.util.Random;

//Aufgabe 2
public class Nr2 {
    public static void main(String[] args) {
        boolean t1,t2,t3; //F�r die T�rauswahl
        short wechsel; //F�r die M�glichkeit, sp�ter die T�r zu wechseln
        boolean doorrand; //Operator, um eine zuf�llige falsche T�r zu �ffnen
        short auswahl; //Zur Auswahl der T�r f�r den User

        Random zufall = new Random();
        int gewinn = zufall.nextInt(2);
        //System.out.println("Die Gewinnt�r leutet: " + gewinn);

        switch(gewinn) {
            case 0:
                t1 = true;
                t2 = false;
                t3 = false;
            case 1:
                t1 = false;
                t2 = true;
                t3 = false;
            case 2:
                t1 = false;
                t2 = false;
                t3 = true;
        } //end switch(gewinn)

        Scanner eingabe = new Scanner(System.in);
        System.out.print("Wie soll der T�rwechsel durchgef�hrt werde? (0:nie, 1:immer, 2:zuf�llig): ");
        wechsel = eingabe.nextShort();

        System.out.print("Bitte w�hlen Sie eine T�r (0 f�r 1, 1 f�r 2 oder 2 f�r 3!): ");
        auswahl = eingabe.nextShort();
        switch(auswahl) {
            case 0:
                if(gewinn == 0) {
                    doorrand = zufall.nextBoolean();
                    if(doorrand == false) {
                        System.out.println("T�r2 wurde ge�ffnet und ist falsch");
                    }
                    else {
                        System.out.println("T�r3 wurde ge�ffnet und ist falsch");
                    }
                    System.out.println("Wollen Sie die T�r wechseln?: " +wechsel);
                    switch(wechsel) {
                        default:
                            System.out.println("Bitte geben Sie valide Werte an!");
                        case 0:
                            System.out.println("Sie haben gewonnen, denn ihre Auswahl "+auswahl+" entspricht: "+gewinn);
                            break;
                        case 1:
                            if(doorrand == false) {
                                auswahl = 2;
                            }
                            else {
                                auswahl = 1;
                            }
                        case 2:
                            doorrand = zufall.nextBoolean();
                            if(doorrand == false) {
                                System.out.println("Sie sind geblieben und haben gewonnen, denn ihre Auswahl "+auswahl+" entspricht: "+gewinn);
                            }
                            else {
                                doorrand = zufall.nextBoolean();
                                if(doorrand == false) {
                                    auswahl = 2;
                                }
                                else {
                                    auswahl = 1;
                                } //end else
                            } //end else
                    } //end switch(wechsel)
                } //end if
                else {
                    System.out.println("Die richtige T�r w�re "+gewinn+" gewesen!");
                    System.out.println("Sie haben leider verloren! Mehr Gl�ck beim n�chsten Mal.");
                } //end else
            case 1:
                if(gewinn == 1) {
                    doorrand = zufall.nextBoolean();
                    if(doorrand == false) {
                        System.out.println("T�r1 wurde ge�ffnet und ist falsch");
                    }
                    else {
                        System.out.println("T�r3 wurde ge�ffnet und ist falsch");
                    }
                    System.out.println("Wollen Sie die T�r wechseln?: " +wechsel);
                    switch(wechsel) {
                        default:
                            System.out.println("Bitte geben Sie valide Werte an!");
                        case 0:
                            System.out.println("Sie haben gewonnen, denn ihre Auswahl "+auswahl+" entspricht: "+gewinn);
                            break;
                        case 1:
                            if(doorrand == false) {
                                auswahl = 2;
                            }
                            else {
                                auswahl = 1;
                            }
                        case 2:
                            doorrand = zufall.nextBoolean();
                            if(doorrand == false) {
                                System.out.println("Sie sind geblieben und haben gewonnen, denn ihre Auswahl "+auswahl+" entspricht: "+gewinn);
                            }
                            else {
                                doorrand = zufall.nextBoolean();
                                if(doorrand == false) {
                                    auswahl = 2;
                                }
                                else {
                                    auswahl = 1;
                                } //end else
                            } //end else
                    } //end switch(wechsel)
                } //end if
                else {
                    System.out.println("Die richtige T�r w�re "+gewinn+" gewesen!");
                    System.out.println("Sie haben leider verloren! Mehr Gl�ck beim n�chsten Mal.");
                } //end else
        }
    } //end switch(auswahl)
    //eingabe.close();
} //end main
//} //end class