import java.util.Random;

public class TreeDoorsSimulator {
    // Ziege = False
    // Auto = True
    boolean[] doors = new boolean[3];
    //Randomizer
    Random randomizer = new Random();

    // Ermittelt, wo das "Auto" hinter steht
    int doorWithCar = randomizer.nextInt(3);


    /// Konstruktor
    public TreeDoorsSimulator()
    {
        this.resetGame();
    }
    /// End Konstruktor


    public void resetGame()
    {
        // Bestimmte Tür mit dem Auto
        int doorWithCar = randomizer.nextInt(3);

        /// for: Bestimmte Werte der Türen
        for (int i = 0; i < doors.length; i++)
        {
            /// if: Setze Werte der Türen
            if (i == doorWithCar)
            {
                System.out.println("Tür mit dem Auto: " + i);
                doors[i] = true;
            }
            else
            {
                doors[i] = false;
            }
            /// End If
        }
        /// END- For
    }


    public boolean play(boolean changingGuess)
    {
        int setDoorPlayer = randomizer.nextInt(3);
        int setDoorModerator = 0;
        boolean moderatorIsNotSet = true;
        boolean newDoorIsNotSet = true;

        resetGame();

        System.out.println("Bestimmte Tür: " + setDoorPlayer);

        for (int i = 0; i < doors.length; i++)
        {


            if (i != setDoorPlayer && doors[i] == false && moderatorIsNotSet)
            {
                setDoorModerator = i;
                System.out.println("Bestimmte Tür des Moderatoren: " + setDoorModerator);
                moderatorIsNotSet = false;
            }
        }

        if (changingGuess)
        {
            for (int i = 0; i < doors.length; i++)
            {
                if (i != setDoorPlayer && i != setDoorModerator && newDoorIsNotSet)
                {
                    setDoorPlayer = i;
                    newDoorIsNotSet = false;
                    System.out.println("Bestimmte neue Tür: " + setDoorPlayer);
                }
            }
        }

        if (doors[setDoorPlayer])
        {
            System.out.println("Gewonnen!");
        }
        else
        {
            System.out.println("Verloren!");
        }

        return doors[setDoorPlayer];

    }


    public double[] testing(int durchlaufe)
    {
        double[] res = new double[3];
        double resNoChangeGuessing = 0;
        double resChangeGuessing = 0;
        double resSometimesChangeGuessing = 0;
        boolean changesGussing;
        Random randomizer = new Random();


        for (int i = 0; i <= durchlaufe; i++)
        {
            if (this.play(false))
            {
                resNoChangeGuessing++;
            }
            if (this.play(true))
            {
                resChangeGuessing++;
            }

            if (randomizer.nextBoolean())
            {
                changesGussing = true;
            }
            else
            {
                changesGussing = false;
            }
            if (this.play(changesGussing))
            {
                resSometimesChangeGuessing++;
            }
        }

        res[0] = (resNoChangeGuessing / durchlaufe) * 100;
        res[1] = (resChangeGuessing / durchlaufe) * 100;
        res[2] = (resSometimesChangeGuessing / durchlaufe) * 100;

        System.out.println("Nie Meinung ändern: " + res[0]);
        System.out.println("Meinung ändern: " + res[1]);
        System.out.println("Manchmal Meinung ändern: " + res[2]);

        return res;
    }

}