import javax.swing.event.ListDataListener;
import java.util.ArrayList;

//Tutor: Dennis Nikolaus Natusch
//Studenten: Simeon Vasilev, Halit Dur, Vincent

//Aufgabe 2

/*
a)
In object-oriented programming, iterators are used if elements are to be inserted or removed in a linked list and
the references of the individual nodes are not disturbed, so the list is not in danger of being changed.
Iterators are therefore particularly useful in cases where we need to add or remove new elements from a list.

b)
Inner classes improve the clarity and is therefore in the first place in a design strategy.
Inner classes can be applied to all elements of the access each outer class while the inner class outside the
defined associated block is not visible to the other classes.
Amongst others, inner classes are used in programming of graphic applications.


//Aufgabe 3
 */

public class ListQueue {
	
	List liste;
	
	public interface Queue<E> {
  
		liste = new List();
		
    public void enqueue(E element) {
    	
    	/* As long as the source is not full, a new element should be addet at the end of the queue
    	  When the Queue reaches the length of 1, a Value of 0
    	  should be set at the end of the queue to mark the end ot the queue
    	  Otherwise, the queue should continue to be extended by one element.
    	 */

    	if (empty(true)) {
    		queue[tail] = element;
    		if (tail == (queue.length-1)) {
    			tail = 0;
    		} else {
    			tail++;
    		}
    	}
    }
    
    public E dequeue() throws EmptyQueueException {

    	if (empty(false)) {
    		E element = queue[head];
    		if (head == (queue.length-1)) {
    			head = 0;
    		} else {
    			head++;
    		}
    		return element;
    	} else {
    		throw new EmptyQueueException();
    	}
    }
    
    public E head() throws EmptyQueueException {
    	
    	/* Here the first element should be printed, not removed if the queue is not empty.
    	Otherwise we get the exception "EmptyQueueException"
    	 */

    	if (empty(false)) {
    		front(E);
    	} else {
    		throw new EmptyQueueException();
    	}
    }
    
    public boolean empty() {
    	
    	/* This returns true, if the last and first element refer to each other,
    	so we can see that we have an empty list.
    	  Otherwise this returns false.
    	 */
    	if (head == tail) {     
    		return true; 
    		} else {
    			return false;
    		}
    }
    
    public String toString() {
    	
    	return liste;
    	
    }
}
	
	public interface Iterable<E> {
		
		Iterator<E> iterator();
		
	}
}