package u8;

import u8.Exceptions.NotEnoughCapacityException;
import u8.Exceptions.NotEnoughFuelException;

public class TestVehicle {

	public static void main(String[] args) {
		Vehicle carObj = new Car();
		Vehicle bikeObj = new Bike();
		Driver driverCarObj = new Driver(carObj);
		Driver driverBikeObj = new Driver(bikeObj);
		

		System.out.println("Driving 300km with 100km/h without refueling");
		try {
			driverCarObj.drive(300, 120);
		} catch (NotEnoughFuelException e) {

			e.printStackTrace();
		}


		System.out.println("Riding Bike 100km with 60km/h without");
		try {
			driverBikeObj.drive(300, 120);
		} catch (NotEnoughFuelException e) {
			e.printStackTrace();
		}

		System.out.println("Refuieling Auto: " + driverCarObj.tankUp());
		System.out.println("Refueling Bike: " + driverBikeObj.tankUp());
		try {
			System.out.println("Driving 300km with 100km/h and refueling");
			System.out.println(driverCarObj.drive(300, 120));
			System.out.println("Riding Bike with 100km and 60km/h and refueling");
			System.out.println(driverBikeObj.drive(100, 50));
		} catch (NotEnoughFuelException e) {
			e.printStackTrace();
		}
		
		System.out.println("Fuel left Auto: " + driverCarObj.getTank() );
		System.out.println("Fuel left Bike: " + driverBikeObj.getTank() );


		int tankCar = driverCarObj.tankUp();
		int tankBike = driverBikeObj.tankUp();
		System.out.println("Refuel Auto: " + tankCar);
		System.out.println("Refuel Bike: " + tankBike);

		System.out.println("Too much fuel in Auto: " + tankCar);
		try {
			driverCarObj.tank(tankCar);
		} catch (NotEnoughCapacityException e) {
			e.printStackTrace();
		}

		System.out.println("Too much fuel in Bike: " + tankBike);
		try {
			driverBikeObj.tank(tankBike);
		} catch (NotEnoughCapacityException e) {
			e.printStackTrace();
		}
		
	}

}
