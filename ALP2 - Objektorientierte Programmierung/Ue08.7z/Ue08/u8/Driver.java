package u8;

import java.sql.Time;
import u8.Exceptions.*;

public class Driver<V extends Vehicle> {
	private V vehicle;
	
	

	public Driver(V vehicle)
	{
		this.vehicle = vehicle;
	}

	// Drive aus Aufgabe 1 d)
	public Time drive(int km, int speed) throws NotEnoughFuelException
	{
		if (speed > vehicle.getMaxSpeed())
		{
			speed = vehicle.getMaxSpeed();
		}

		double current = (double) (km) / (double) (speed);
		int hours = 0;
		int minutes = 0;
		int seconds = 0;
		
		int hundertKm = (int) (km / 100);
		double neededGas =  (int) (hundertKm * vehicle.getGasProKm());

		if (neededGas > vehicle.getCurrentGas())
		{
			throw new NotEnoughFuelException();
		}

		while (current - 1 >= 0)
		{
			hours++;
			current -= 1;
		}

		current = 60 * current;
		
		while (current - 1 >= 0)
		{
			minutes++;
			current -= 1;
		}

		current = 60 * current;
		
		while (current - 1 >= 0)
		{
			seconds++;
			current -= 1;
		}

		vehicle.driveKm(300);

		String timeStr = Integer.toString(hours) + ":" + Integer.toString(minutes) + ":" + Integer.toString(seconds);

		return Time.valueOf(timeStr);
	}
	
	public int tankUp()
	{
		int maxGas = vehicle.getMaxGas();
		int currentGas = vehicle.getCurrentGas();
		int difGas = maxGas - currentGas;


		try {
			this.tank(difGas);
		} catch (NotEnoughCapacityException e) {
			e.printStackTrace();
		}

		return difGas;
	}
	
	public void tank(int liter) throws NotEnoughCapacityException
	{
		if (vehicle.getCurrentGas() + liter > vehicle.getMaxGas())
		{
			throw new NotEnoughCapacityException();
		}
		vehicle.fillGas(liter);
	}
	
	public boolean isEmpty()
	{ return ( vehicle.getCurrentGas() == 0 ); }
	
	public boolean isFull()
	{ return ( vehicle.getCurrentGas() == vehicle.getMaxGas() ); }
	
	public int getTank()
	{
		return vehicle.getCurrentGas();
	}


}
