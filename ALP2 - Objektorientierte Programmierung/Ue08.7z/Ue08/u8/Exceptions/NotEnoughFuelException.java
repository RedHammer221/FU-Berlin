package u8.Exceptions;

public class NotEnoughFuelException extends Exception{
	public NotEnoughFuelException()
	{
		super("Out of gas!");
		
	}

}
