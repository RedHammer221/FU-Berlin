package u8.Exceptions;

public class NotEnoughCapacityException extends Exception{
	public NotEnoughCapacityException()
	{
		super("Not enough capacity for the refuel!");
	}

}
