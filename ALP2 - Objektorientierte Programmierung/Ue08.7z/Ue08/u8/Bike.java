package u8;

import java.awt.Color;

import javax.management.MXBean;

public class Bike extends Vehicle{
	private boolean hadHelmetBox;
	private boolean isHelmetBoxFilled = false;

	protected Bike(String name, char licenseclass, String ventor, int maxGas, double literPerKm, Color color,
			int produceyear, int doors, int tare, int maxTare, int ps, int topSpeed, boolean hadHelmetBox) {
		super(name, licenseclass, ventor, maxGas, literPerKm, color, produceyear, doors, tare, maxTare, ps, topSpeed);

		this.hadHelmetBox = hadHelmetBox;
	}
	

	protected Bike() {
		super("YZF", 'M', "Yamaha", 18, 5.5, Color.BLUE, 1998, 0, 78, 260, 130, 270);

		this.hadHelmetBox = true;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public char getLicenseclass() {
		return licenseclass;
	}

	@Override
	public String getVentor() {
		return ventor;
	}

	@Override
	public int getMaxGas() {
		return maxGas;
	}

	@Override
	public double getLiterPerKm() {
		return literPerKm();
	}

	@Override
	public Color getColor() {
		return color;
	}

	@Override
	public int getProduceyear() {
		return produceyear;
	}

	@Override
	public int getDoors() {
		return doors;
	}

	@Override
	public int getTare() {
		return tare;
	}

	@Override
	public int getMaxTare() {
		return maxTare;
	}

	@Override
	public int getPS() {
		return ps;
	}

	@Override
	public int getTopSpeed() {
		return topSpeed;
	}

	@Override
	public void fillGas(int newGas) {
		currentGas += newGas;
		
		if (currentGas > maxGas)
		{
			isWorking = false;
		}
		
	}
		
	@Override
	public void setCurrentspeed(int currentspeed) {
		currentspeed += currentspeed;
		
		if (currentspeed > topSpeed) { isWorking = false; }
	}

	@Override
	public void addMileage(int newKm) {
		if (isWorking) { mileage += newKm; }
	}

	@Override
	public void repair() {
		 isWorking = true;
		 currentSpeed = 0;
		 currentGas = 0;
		 currentTare = tare;
	}

	@Override
	public void addLoad(int newTare) {
		currentTare += newTare;
		if (currentTare > maxTare) { isWorking = false; }
	}

	@Override
	public void removeLoad(int tokenTare) {
		currentTare -= tokenTare;
		if (currentTare < tare) { currentTare = tare; }
		
	}
	
	public boolean hadHelmetBox()
	{
		return hadHelmetBox;
	}
	
	public boolean isHelmetboxFilled()
	{
		return isHelmetBoxFilled;
	}
	
	public void fillHelmetBox()
	{
		if (hadHelmetBox)
		{
			isHelmetBoxFilled = true;
		}
	}
	
	public void unfilledHelmetBox()
	{
		isHelmetBoxFilled = false;
	}

	@Override
	public int getCurrentGas() {
		return currentGas;
	}

	@Override
	public int getMileage() {
		return mileage;
	}

	@Override
	public void driveKm(int km) {
		int neededGas = (int) ((km / 100) * literPerKm);
		currentGas -= neededGas;
		mileage += km;

	}

}
