package u8;

import java.awt.Color;

public class Car extends Vehicle{

	public Car(String name, char licenseclass, String ventor, int maxGas,
			double literPerKm, Color color, int produceyear, int doors, int tare, int maxTare, int ps, int topSpeed)
	{
		super(name, licenseclass, ventor, maxGas, literPerKm,
				color, produceyear, doors, tare, maxTare, ps, topSpeed);
	}


	protected Car()
	{
		super("Zaporozhets", 'B', 'ZAZ', 30, 2.6,
				Color.RED, 1960, 2, 300, 950, 23, 110);
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public char getLicenseclass() {
		return licenseclass;
	}

	@Override
	public String getVentor() {
		return ventor;
	}

	@Override
	public int getMaxGas() {
		return maxGas;
	}

	@Override
	public double getLiterPerKm() {
		return literPerKm;
	}

	@Override
	public Color getColor() {
		return color;
	}

	@Override
	public int getProduceyear() {
		return produceyear;
	}

	@Override
	public int getDoors() {
		return doors;
	}

	@Override
	public int getTare() {
		return tare;
	}

	@Override
	public int getMaxTare() {
		return maxTare;
	}

	@Override
	public int getPS() {
		return ps;
	}

	@Override
	public int getTopSpeed() {
		return topSpeed;
	}

	@Override
	public void fillGas(int newGas) {
		currentGas += newGas;

		if (currentGas > maxGas)
		{
			isWorking = false;
		}
		
	}

	@Override
	public void setCurrentspeed(int currentspeed) {
		currentspeed += currentspeed;
		
		if (currentspeed > maxSpeed) { isWorking = false; }
		
	}

	@Override
	public void addMileage(int newKm) {
		if (isWorking) { mileage += newKm; }	
	}

	@Override
	public void repair() {
		 isWorking = true;
		 currentSpeed = 0;
		 currentGas = 0;
		 currentTare = tare;
	}

	@Override
	public void addLoad(int newTare) {
		currentTare += newTare;
		if (currentTare > maxTare) { isWorking = false; }
	}

	@Override
	public void removeLoad(int tokenTare) {
		currentTare -= tokenTare;
		if (currentTare < tare) { currentTare = tare; }
	}

	@Override
	public int getCurrentGas() {
		return currentGas;
	}

	@Override
	public int getMileage() {
		return mileage;
	}

	@Override
	public void driveKm(int km) {
		int neededGas = (int) ((km / 100) * gasProKm);
		
		if (neededGas <= currentGas)
		{
			currentGas -= neededGas;
			mileage += km;
		}
		
	}

}
