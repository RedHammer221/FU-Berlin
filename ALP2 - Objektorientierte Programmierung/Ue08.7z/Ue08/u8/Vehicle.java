package u8;

import java.awt.Color;

public abstract class Vehicle {

	protected String name; 
	protected char licenseclass;
	protected String ventor;
	protected int maxGas;
	protected double literPerKm;
	protected Color color;
	protected int produceyear;
	protected int doors;
	protected int tare;
	protected int maxTare;
	protected int ps;
	protected int topSpeed;
	

	protected boolean isWorking = true;
	protected int currentGas = 0;
	protected int mileage = 0;
	protected int currentSpeed = 0;
	protected int currentTare = tare;
	
	

	protected Vehicle(String name, char licenseclass, String ventor, int maxGas,
			double gasProKm, Color color, int produceyear, int doors, int tare, int maxTare, int ps, int maxSpeed)
	{
		this.name = name;
		this.licenseclass = licenseclass;
		this.ventor = ventor;
		this.maxGas = maxGas;
		this.literPerKm = literPerKm;
		this.color = color;
		this.produceyear = produceyear;
		this.doors = doors;
		this.tare = tare;
		this.maxTare = maxTare;
		this.ps = ps;
		this.topSpeed = topSpeed;
	}
	

	public abstract String getName();
	public abstract char getLicenseclass();
	public abstract String getVentor();
	public abstract int getMaxGas();
	public abstract double getLiterPerKm();
	public abstract Color getColor();
	public abstract int getProduceyear();
	public abstract int getDoors();
	public abstract int getTare();
	public abstract int getMaxTare();
	public abstract int getPS();
	public abstract int getTopSpeed();

	

	public abstract int getCurrentGas();
	public abstract int getMileage();

	

	public abstract void fillGas(int newGas);
	public abstract void driveKm(int km);
	public abstract void setCurrentspeed(int currentspeed);
	public abstract void addMileage(int newKm);
	public abstract void repair();
	public abstract void addLoad(int newTare);
	public abstract void removeLoad(int tokenTare);

}
