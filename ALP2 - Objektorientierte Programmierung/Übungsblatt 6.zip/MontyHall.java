import java.util.Random;
/*public class Door{
	string inhalt;
	public Door(string inhalt){
		this.inhalt=inhalt;
	}
	// method 1 
    public String getInhalt(){ 
        return inhalt; 
    } 
	
}
*/
public class MontyHall{
	String Door0;
	String Door1;
	String Door2;
	String[] Doors;
	int chosenDoor;
	int openedDoor;
	int finalDoor;
	
	public MontyHall(){
		int z;
		Random preis = new Random();
		z = 1+ preis.nextInt(3);
		if (z==0){
			this.Door0 = "Auto";
			this.Door1 = "Ziege";
			this.Door2 = "Ziege";
		}
		else if (z==2){
			this.Door0 = "Ziege";
			this.Door1 = "Ziege";
			this.Door2 = "Auto";		
		}
		else{
			this.Door0 = "Ziege";
			this.Door1 = "Auto";
			this.Door2 = "Ziege";		
		}
		Random choice = new Random();
		this.chosenDoor = choice.nextInt(3);
		this.Doors= new String[]{Door0, Door1, Door2};
	}
	
	public int stay() {
		if ("Auto" == Doors[chosenDoor])
				return 1;
		return 0;
	}
	
	public int change() {
		do {
			Random open = new Random();
			openedDoor =  open.nextInt(3);
		}while(openedDoor==chosenDoor || Doors[openedDoor]=="Auto");
		//neue Wahl
		do {
			Random choice = new Random();
			finalDoor =  choice.nextInt(3);
		}while(finalDoor==chosenDoor || finalDoor==openedDoor);
		if (Doors[finalDoor]=="Auto")
				return 1;
		return 0;
	}
	public int random() {
		do {
			Random open = new Random();
			openedDoor = open.nextInt(3);
		}while(openedDoor==chosenDoor || Doors[openedDoor]=="Auto");
		do {
			Random choice = new Random();
			finalDoor = choice.nextInt(3);
		}while(finalDoor==openedDoor);
		if (Doors[finalDoor]=="Auto")
			return 1;
		return 0;
	}
	
	public static void main(String[] args) {
		double percStay=0;
		double percChange=0;
		double percRand=0;
		for(int i=0;i<1000000;i++) {
			MontyHall Stay = new MontyHall();
			MontyHall Change = new MontyHall();
			MontyHall Rand = new MontyHall();
			percStay+= Stay.stay();
			percChange+= Change.change();
			percRand+= Rand.random();
			//System.out.println(Stay.stay());
		}
		percStay= percStay/1000000;
		percChange=percChange/1000000;
		percRand=percRand/1000000;
		System.out.println("Es wurden jeweils 1.000.000 Spiele simuliert.");
		System.out.println("Wenn man immer auf der ersten Wahl beharrt, hat man im Mittel eine Gewinnrate von "+100*percStay+"%.");
		System.out.println("Wenn man seine Wahl immer �ndert, hat man im Mittel eine Gewinnrate von "+100*percChange+"%.");
		System.out.println("Wenn man immer den Zufall entscheiden l�sst, hat man im Mittel eine Gewinnrate von "+100*percRand+"%.");
	}
}