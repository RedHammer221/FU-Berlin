import java.lang.Math;

public class Spirograph {
	public static void main( String[] args) {
		int a=1;
		double b=1.0/2;
		double c=1.0/3;
		int m = 7;
		int n = 17;
		StdDraw.setXscale(0, 600);
		StdDraw.setYscale(0, 600);
		for(double t=-5; t<=5; t= t+0.001) {
			double x = a * Math.cos(t) + b * Math.cos(m * t) + c * Math.sin(n * t);
			double y = a * Math.sin(t) + b * Math.sin(m * t) + c * Math.cos(n * t);
			StdDraw.point(250 + 150 * x, 250 + 150 * y);
		}
		System.out.println("Man muss t eigentlich nur von -5 bis ca. 1,3 laufen lassen, ab 1,3 zeichnet man nochmal über die die Form rüber");

	}
}