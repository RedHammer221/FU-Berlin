public class Stars {
	int x;
	int y;
	int size;
	
	public Stars( int x,int y,int size) {
		this.x = x;
		this.y = y;
		this.size=size;
	}
	
	public void draw() {
		int[] p0= {x,y+size};
		int[] p1= {x+size/7,y+size/7};
		int[] p2= {x+size,y};
		int[] p3= {x+size/7,y-size/7};
		int[] p4= {x,y-size};
		int[] p5= {x-size/7,y-size/7};
		int[] p6= {x-size,y};
		int[] p7= {x-size/7,y+size/7};
		int[][] A= {p0,p1,p2,p3,p4,p5,p6,p7};
		for(int i = 0; i<8 ;i++) {
			StdDraw.line(A[i%8][0], A[i%8][1], A[(i+1)%8][0], A[(i+1)%8][1]);
		}
	}
	
	
	public static void main( String[] args) {
		StdDraw.setXscale(0, 500);
		StdDraw.setYscale(0, 500);
		StdDraw.setPenColor(StdDraw.BOOK_BLUE);
		for(int i=0;i<100;i++) {
			int x= (int) (Math.random()*500);
			int y= (int) (Math.random()*500);
			int size= (int) (Math.random()*40);
			Stars s1 = new Stars(x,y,size);
			s1.draw();
		}
	}
}