import java.lang.Math;

public class ZInteger {
	final int x,y;
	
	public ZInteger(int x, int y) {
		if (x<0 || y<0) 
			throw new IllegalArgumentException("Gebe gültige (positive, ganzzahlige) Werte ein!");
		this.x = x;
		this.y = y;
	}
	public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
	public ZInteger simplify() {
		int Min = Math.min(x,y);
		return new ZInteger(x - Min, y - Min);
	}
	public ZInteger add(ZInteger c) {
		return new ZInteger(x+c.x, y+c.y);
	}
	public ZInteger sub(ZInteger c) {
		int diffX = x-c.x;
		int diffY = y-c.y;
		if (diffX<0 || diffY<0) {
			int Min = Math.abs(Math.min(diffX, diffY));
			return new ZInteger(x-c.x+Min, y-c.y+Min);
		}
		return new ZInteger(x-c.x, y-c.y);
	}
	public ZInteger multpl(ZInteger c) {
		int prod=(c.x-c.y)*(x-y);
		if (prod<0)
			return new ZInteger((-1)*(c.x-c.y)*(x-y),0);
		else
			return new ZInteger(0, (c.x-c.y)*(x-y));
	}
	public boolean equals(ZInteger c) {
		if (y-x==c.y-c.x)
			return true;
		return false;
	}
	public boolean less(ZInteger c) {
		if (y-x<c.y-c.x)
			return true;
		return false;
	}
	public boolean lessEq(ZInteger c) {
		if (y-x<=c.y-c.x)
			return true;
		return false;
	}
	public boolean greater(ZInteger c) {
		if (y-x>c.y-c.x)
			return true;
		return false;
	}
	public boolean greaterEq(ZInteger c) {
		if (y-x>=c.y-c.x)
			return true;
		return false;
	}
	@Override
	public String toString() {
		String string = "("+x+","+y+")";
		return string;
	}
	public static void main(String[] args) {
	}
}
