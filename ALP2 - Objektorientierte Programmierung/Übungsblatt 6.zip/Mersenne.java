import java.lang.Math;
public class Mersenne {
	public static int mersenne(int k) {
		int base=2;
		int mersenneV=1;
		for(int i=0; i<k; i++) {
			mersenneV = base-1;
			base <<= 1;
		}
		return mersenneV;
	}
	
	public static int mersenneWhile(int k) {
		//{P}={k>=0}
		assert k>=0;
		int base=2;
		int mersenneV=1;
		int i=0;
		while (i<k) {
			//{INV}={i<k and (Es exisitiert x element N, sodass: mersenneV=(2^x)-1)}
			assert i<k;
			assert (1.0*(mersenneV+1)/2)%1 == 0;
			mersenneV = base-1;
			base <<= 1;
			i++;
			
		}
		//{Q}={mersenneV=2^(k-1)-1 and i>=k}
		assert mersenneV == Math.pow(2, k-1)-1;
		return mersenneV;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
