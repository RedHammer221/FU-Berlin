import java.lang.Math;
    public class Circle {
        private double x;
        private double y;
        private double radius;
        static final float PI = 3.1415926535f;

        public Circle(double x, double y, double radius) {
            this.x = x;
            this.y = y;
            this.radius = radius;
        }
        public Circle() {
            this(0, 0, 10);
        }

        public double getX() {
            return x;
        }
        
        public double getY() {
            return y;
        }

        public double getRadius(){
            return radius;
        }
        
        public double getArea() {
            return (PI * radius * radius);
        }

        @Override
        public Circle clone() {
            return new Circle(x, y, radius);
        }

        public int compareTo(Circle c) {
            if (getArea() > c.getArea()) {
                return 1;
            }
            else if (getArea() == c.getArea()) {
                return 0;
            }
            else {
                return -1;
            }
        }

        public boolean contains(Circle c) {
            double distance = Math.sqrt(Math.pow(x - c.getX(), 2) + Math.pow((y - c.getY()),2));
            return (c.getRadius() + distance <= radius);
        }

        public boolean overlaps(Circle c) {
            double distance = Math.sqrt(Math.pow(x - c.getX(), 2) + Math.pow(y - c.getY(),2));
            return (distance < c.getRadius() + radius);
        }

        public static Rectangle smallestBoundingRectangle(Circle[] circles) {
            double minX = circles[0].getX();
            double maxX = circles[0].getX();
            double minY = circles[0].getY();
            double maxY = circles[0].getY();
            for (int i = 0; i < circles.length; i++) {
                if (circles[i].getX() - circles[i].getRadius() < minX) {
                    minX = circles[i].getX() - circles[i].getRadius();
                }
                if (circles[i].getX() + circles[i].getRadius() > maxX) {
                    maxX = circles[i].getX() + circles[i].getRadius();
                }
                if (circles[i].getY() + circles[i].getRadius() > maxY) {
                    maxY = circles[i].getY() + circles[i].getRadius();
                }
                if (circles[i].getY() - circles[i].getRadius() < minY) {
                    minY = circles[i].getY() - circles[i].getRadius();
                }
            }
            double width = Math.abs(maxX - minX);
            double height = Math.abs(maxY - minY);
            Rectangle boundingRect = new Rectangle(minX, minY, width, height);
            return boundingRect;
        }

        public static void main( String[] args) {
        	Circle c1 = new Circle();
        	Circle c2 = new Circle(50,25,20);
        	Circle c3 = new Circle(20, 70, 3);
        	Circle[] arr = {c1,c2,c3};
        	
    		StdDraw.setXscale(-100,200);
    		StdDraw.setYscale(-100,200);
    		StdDraw.circle(c1.getX(),c1.getY(),c1.getRadius());
    		StdDraw.circle(c2.getX(),c2.getY(),c2.getRadius());
    		StdDraw.circle(c3.getX(),c3.getY(),c3.getRadius());

    		Rectangle rect = smallestBoundingRectangle(arr);
    		double xc = rect.x+ rect.width/2;
    		double yc = rect.y + rect.height/2;
    		
    		StdDraw.rectangle(xc,yc,rect.getWidth()/2, rect.getHeight()/2);
    		System.out.println(rect.x);
    		System.out.println(rect.y);
    		System.out.println(rect.x);
        }
}
