public class Rectangle {
    // Attribute
    double x;
    double y;
    double width;
    double height;

    // Konstruktor
    public Rectangle(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    // Methoden
    public double perimeter() {
        return 2 * (width + height);
    }

    public double area() {
        return (width * height);
    }
    
    public double getY() {
        return y;
    }

    public double getX() {
        return x;
    }
    
    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }
    
    public static void main( String[] args) {
    }

}