
public class MickeyMouse {
	public static void drawFractal(double xc, double yc, double r, int depth) {
		if (depth==0)
			return;
		StdDraw.filledCircle(xc, yc, r);
		drawFractal(xc-r, yc-r, r/2, depth-1);
		drawFractal(xc-r, yc+r, r/2, depth-1);
		drawFractal(xc+r, yc+r, r/2, depth-1);
		drawFractal(xc+r, yc-r, r/2, depth-1);
	}
	public static void main(String[] args) {
		int size=200;
		StdDraw.setXscale(0, size);
		StdDraw.setYscale(0, size);
		drawFractal(size/2, size/2, size/4, 6);
	}

}
