
public class Bauernregel {
	public static int bauernRegel(int a, int b) {
		int ergb = 0;
		while(a>0) {
			if((a&1) != 0) {
				ergb += b;
			}
			a = a>>1;
			b = b<<1;
		}
		return ergb;
	}
	/* Der Algorithmus hat eine Komplexität von log_2(a), also gilt T(a,b)=O(log_2(a)). Die erste Zahl a wird nach jedem Schleifendurchlauf
	    halbiert, bis 0 rauskommt, es gibt also log_2(a) Schleifendurchgänge. */
	public static void main(String[] args) {
		System.out.println(bauernRegel(5,47));

	}

}
