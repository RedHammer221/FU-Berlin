public class TestZInteger {
	public static void testMutable() {
		ZInteger a = new ZInteger(3,0);
		//try {
			//a.x=4;
			//a.y=4;
		//} catch (Error e) {
		//	System.out.println("Ein Fehler");;
		//}
		System.out.println("Die einzelnen Koordinaten der ZInteger Zahl "+ a.toString() + " sind unveränderlich, nimm dafür die Kommentaranweisung aus der testMutable " +
				"Methode raus und siehe selbst. Es funktioniert halt nicht mal in nem try-catch Block.");
	}
	public static void testSimplify() {
		ZInteger b = new ZInteger(11,5);
		ZInteger c = new ZInteger(3,8);
		System.out.println("b simplifiziert: "+ b.simplify().toString());
		System.out.println("c simplifiziert: "+ c.simplify().toString());
	}
	public static void testAdd() {
		ZInteger a = new ZInteger(3,0);
		ZInteger b = new ZInteger(11,5);
		ZInteger c = new ZInteger(3,8);
		ZInteger d = new ZInteger(5,15);
		System.out.println("a+c ergibt: "+ a.add(c).toString());
		System.out.println("a+c ergibt: "+ b.add(d).toString());
	}
	public static void testSub() {
		ZInteger a = new ZInteger(3,0);
		ZInteger b = new ZInteger(11,5);
		ZInteger c = new ZInteger(3,8);
		ZInteger d = new ZInteger(5,15);
		System.out.println("a-c ergibt: "+ a.sub(c).toString());
		System.out.println("b-d ergibt: "+ b.sub(d).toString());
	}
	public static void testMultpl() {
		ZInteger a = new ZInteger(3,0);
		ZInteger b = new ZInteger(11,5);
		ZInteger c = new ZInteger(3,8);
		ZInteger d = new ZInteger(5,15);
		System.out.println("a*c ergibt: "+ a.multpl(c).toString());
		System.out.println("b*d ergibt: "+ b.multpl(d).toString());
	}
	public static void testEquals() {
		ZInteger b = new ZInteger(11,5);
		ZInteger c = new ZInteger(3,8);
		ZInteger d = new ZInteger(5,15);
		ZInteger e = new ZInteger(0,10);
		System.out.println("b=c "+ b.equals(c));
		System.out.println("d=e "+ d.equals(e));
	}
	public static void testLess() {
		ZInteger a = new ZInteger(3,0);
		ZInteger b = new ZInteger(11,5);
		ZInteger c = new ZInteger(3,8);
		System.out.println("a<b "+ a.less(b));
		System.out.println("b<c "+ b.less(c));
	}
	public static void testLessEq() {
		ZInteger a = new ZInteger(3,0);
		ZInteger d = new ZInteger(5,15);
		ZInteger e = new ZInteger(0,10);
		System.out.println("a<=d "+ a.lessEq(d));
		System.out.println("d<=e "+ d.lessEq(e));
	}
	public static void testGreater() {
		ZInteger a = new ZInteger(3,0);
		ZInteger b = new ZInteger(11,5);
		ZInteger c = new ZInteger(3,8);
		System.out.println("a>b "+ a.greater(b));
		System.out.println("b>c "+ b.greater(c));
	}
	public static void testGreaterEq() {
		ZInteger a = new ZInteger(3,0);
		ZInteger d = new ZInteger(5,15);
		ZInteger e = new ZInteger(0,10);
		System.out.println("a>=d "+ a.greaterEq(d));
		System.out.println("d>=e "+ d.greaterEq(e));
	}
	public static void testToString() {
		ZInteger a = new ZInteger(3,0);
		ZInteger b = new ZInteger(11,5);
		ZInteger c = new ZInteger(3,8);
		ZInteger d = new ZInteger(5,15);
		ZInteger e = new ZInteger(0,10);
		System.out.println("a als Tupel: " + a.toString());
		System.out.println("b als Tupel: " + b.toString());
		System.out.println("c als Tupel: " + c.toString());
		System.out.println("d als Tupel: " + d.toString());
		System.out.println("e als Tupel: " + e.toString());
	}
	
	
	public static void main(String[] args) {
		ZInteger a = new ZInteger(3,0);
		ZInteger b = new ZInteger(11,5);
		ZInteger c = new ZInteger(3,8);
		ZInteger d = new ZInteger(5,15);
		ZInteger e = new ZInteger(0,10);
		testSimplify();
		System.out.println();
		testAdd();
		System.out.println();
		testSub();
		System.out.println();
		testMultpl();
		System.out.println();
		testEquals();
		System.out.println();
		testLess();
		System.out.println();
		testLessEq();
		System.out.println();
		testGreater();
		System.out.println();
		testGreaterEq();
		System.out.println();
		testToString();
		System.out.println();
		testMutable();
	}

}