public class Eye {
	public static void main( String[] args) {
		StdDraw.setXscale(0, 200);
		StdDraw.setYscale(0, 200);
		
		for(int i = 0;i<=50;i++) {
			StdDraw.line(4*i, 0, 0, 200-4*i);
		}
		StdDraw.setPenColor(StdDraw.BLUE);
		for(int i = 0;i<=50;i++) {
			StdDraw.line(4*i, 200, 200, 200-4*i);}
		StdDraw.setPenColor(StdDraw.GREEN);
		for(int i = 0;i<=50;i++) {
			StdDraw.line(4*i, 4*i, 200, 200-4*i);}
		StdDraw.setPenColor(StdDraw.MAGENTA);
		for(int i = 0;i<=50;i++) {
			StdDraw.line(4*i, 200-4*i, 200, 4*i);}
		
}
}
